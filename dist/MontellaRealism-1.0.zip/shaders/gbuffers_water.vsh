#version 330 compatibility
#define VSH
#define WORLD 0
#include "/program/gbuffers_translucent.glsl"
