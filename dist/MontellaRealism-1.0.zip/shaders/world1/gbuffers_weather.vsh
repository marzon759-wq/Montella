#version 330 compatibility
#define VSH
#define WORLD 1
#include "/program/gbuffers_weather.glsl"
